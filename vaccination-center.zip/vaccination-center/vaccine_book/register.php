<?php

require('../connection.php');
session_start();

//print_r($_SESSION);
if((!in_array("loggedIn", $_SESSION)) || $_SESSION['loggedIn']!==true){
    echo "<script>window.href='home.php'</script>";
    die();
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vaccination Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body>

    <div class="container" style="background-color: rgb(227, 207, 207);">
        <div class="row p-5">
            <div class="col">
                <img src="./vacci.jpeg" class="img-fluid" alt="Responsive image" width="100%" height="100%">
            </div>
            <div class="col">
                <center>
                    <h1>COVID-19 Vaccine Registration Form</h1>
                </center>
                <form action="#" method="POST">


                    <div class="row">
                        <div class="col">
                            <label for="formGroupExampleInput" class="m-2">First Name :</label>
                            <input required type="text" class="form-control" id="formGroupExampleInput" name='f_name'>
                            <label for="formGroupbirthdate" class="m-2">Birth Date :</label>
                            <input required type="date" class="form-control" id="formGroupbirthdate" name='dob'>
                            <label for="formGroupExampleInput" class="m-2">Age :</label>
                            <input required type="text" class="form-control" id="formGroupExampleInput" name='age'>
                            <label for="formGroupExampleInput" class="m-2">Email :</label>
                            <input required type="email" class="form-control" id="formGroupExampleInput" name='email'>
                            <label for="formGroupExampleInput" class="m-2">Address :</label>
                            <input required type="text" class="form-control" id="formGroupExampleInput" name='address'>

                            <form class="form-inline">
                                <label class="m-3" for="inlineFormCustomSelectPref">Vaccine Type:</label>
                                <select required class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name='dose_type'>
                                    <option selected>Covishield</option>
                                    <option value="Covishield">Covishield</option>
                                    <option value="COvaxin">COvaxin</option>
                                    <option value="Sputnik V">Sputnik V</option>
                                    <option value="Corbevax">Corbevax</option>
                                </select>
                        </div>
                        <div class="col">
                            <label for="formGroupExampleInput" class="m-2">Last Name :</label>
                            <input required type="text" class="form-control" id="formGroupExampleInput" name='l_name'>
                            <label for="formGroupbirthdate" class="m-2">gender :</label>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input required type="radio" id="customRadioInline1" name='gender'
                                    class="custom-control-input" value="MALE">
                                <label class="custom-control-label" for="customRadioInline1">Male</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input required type="radio" id="customRadioInline2" name='gender'
                                    class="custom-control-input" value="FEMALE">
                                <label class="custom-control-label" for="customRadioInline2">Female</label>
                            </div>
                            <label for="formGroupExampleInput" class="m-2">Phone Number:</label>
                            <input required type="text" class="form-control" id="formGroupExampleInput" name='mobile_no'>
                            <label for="formGroupExampleInput" class="m-2">City :</label>
                            <input required type="text" class="form-control" id="formGroupExampleInput" name='city'>


                            <form class="form-inline">
                                <label class="m-3" for="inlineFormCustomSelectPref">Select Dose :</label>
                                <select required class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name='dose_no'>
                                    <option selected value='Dose 1'>Dose 1</option>
                                    <option value="Dose 2">Dose 2</option>
                                    <option value="Booster Dose">Booster Dose</option>
                                </select>

                            </form>
                            <div class="form-check">
                                <input required class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault">
                                    All Accept
                                </label>
                            </div>
                        </div>
                        <button type="submit" name='submit' class="btn btn-primary my-1">Submit</button>
                    </div>

                </form>
            </div>
        </div>
    </div>


<?php

if(isset($_POST['submit'])){

$f_name = $_POST['f_name'];
$dob = $_POST['dob'];
$age = $_POST['age'];
$email = $_POST['email'];
$address = $_POST['address'];
$dose_type = $_POST['dose_type'];
$l_name = $_POST['l_name'];
$gender = $_POST['gender'];
$gender = $_POST['gender'];
$mobile_no = $_POST['mobile_no'];
$city = $_POST['city'];
$dose_no = $_POST['dose_no'];

$user_id = $_SESSION['user_id'];
$query = "INSERT INTO `booking` (`id`, `user_id`,`f_name`, `l_name`, `email`, `dob`, `age`, `address`, `vaccine_type`, `gender`, `mobile_no`, `city`, `dose_no`, `status`, `created_at`) VALUES (NULL, '$user_id', '$f_name', '$l_name', '$email', '$dob','$address' ,'$age', '$dose_type', '$gender', '$mobile_no', '$city', '$dose_no','1', current_timestamp());";

$result = $conn->query($query);
if($conn->error){
    echo "<script>alert('".$conn->error."');</script>";
}else{
    echo "<script>alert('Vaccine Booked');window.href='home.php'</script>";
}

}


?>








    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>
</body>

</html>