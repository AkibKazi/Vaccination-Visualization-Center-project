<?php

require('../connection.php');
session_start();

if($_SESSION['loggedIn']!==true){
    header('../login/index.php');
}

$bookData = null;
if(isset($_GET['id'])){
    $bookId = $_GET['id'];

    $result = $conn->query("SELECT * from booking where id = '$bookId'; ");

    if($result->num_rows > 0 ){
        $bookData = $result->fetch_assoc();
        $date = date('Y-m-d', strtotime("+6 months", strtotime($bookData['created_at'])));
    }else{
        die("No Bookings");
    }
}else{
    die("Server Error");
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vaccination Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="max-width:600px; ">
        <div class="row">
            <div class="col ">
                <img src="./head.png" class="rounded mx-auto d-block" alt="logo certificate">
                <center>
                    <h4>Provisional Certificate for COVID-19 Vaccination -</h4>
                </center>
                <div class="row">
                    <div class="col">
                        <!-- <h4><u>Beneficiary Details</u></h4>
                        <h5>Age</h5>
                        <h5>Gender</h5>
                        <h5>ID Verified</h5>
                        <h5>Unique Health ID(UHID)</h5>
                        <h5>Beneficiary Reference ID</h5>
                        <p></p>
                        <h5><u>Vaccination Details</u></h5>
                        <h5>Vaccine Name</h5>
                        <h5>Date of Dose</h5>
                        <h5>Next due date</h5>
                        <h5>Vaccination by</h5>
                        <h5>Vaccnaiton at</h5> -->
                        <table class="table table-borderless mt-4" style="max-width: 500px;">
                            <thead>
                                <tr>
                                    <th scope="col"><u>Beneficiary Details</u></th>
                                    <th scope="col"><?=$bookData['f_name']?> <?=$bookData['l_name']?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th scope="row">Age</th>
                                    <td><?=$bookData['address']?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Gender</th>
                                    <td><?=$bookData['gender']?></td>
                                </tr>
                                <tr>
                                    <th scope="row">ID Verified</th>
                                    <td colspan="2"><?=$bookData['id']?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Unique Health ID(UHID)</th>
                                    <td><?=$bookData['user_id']?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Beneficiary Reference ID</th>
                                    <td>234234232</td>
                                </tr>
                                <tr>
                                    
                                </tr>
                                <tr>
                                    <th scope="row"><u>Vaccination Details</u></th>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Vaccine Name</th>
                                    <td><?=$bookData['vaccine_type']?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Date</th>
                                    <td><?=$bookData['created_at']?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Next due date</th>
                                    <td><?=$date?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Vaccination by</th>
                                    <td>Dr.Sunil hogade</td>
                                </tr>
                                <tr>
                                    <th scope="row">Vaccnaiton at</th>
                                    <td>Solapur</td>
                                </tr>
                            </tbody>
                        </table>.
                        </table>
                    </div>
                </div>
                <div class="f-cer">
                    <img src="./footer.png" alt="Bottom certificate" width="100%" class="">
                </div>
            </div>
        </div>
    </div>









    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>
<script>
window.onload = function(){
    print();
};
console.log(231231312)
</script>
</body>

</html>