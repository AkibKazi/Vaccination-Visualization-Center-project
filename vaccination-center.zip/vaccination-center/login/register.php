<?php

require('../connection.php');
session_start();

//print_r($_SESSION);

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vaccination Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section class="vh-100" style="background-color: #4d4a4a;">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-xl-10">
                    <div class="card" style="border-radius: 1rem;">
                        <div class="row g-0">
                            <div class="col-md-6 col-lg-5 d-none d-md-block">
                                <img src="./img/login-logo.jpg" alt="login form" class="img-fluid"
                                    style="border-radius: 1rem 0 0 1rem;" />
                            </div>
                            <div class="col-md-6 col-lg-7 d-flex align-items-center">
                                <div class="card-body p-4 p-lg-5 text-black">

                                    <form method="POST">

                                        <div class="d-flex align-items-center mb-3 pb-1">
                                            <!-- <h2> <i class="bi bi-virus2"></i></h2> -->
                                            <img src="./img/nav-logo.jpg" class="img-fluid mt-5 img-log" alt="...">
                                            <span class="h1 fw-bold mb-0">Vaccination Center</span>
                                        </div>

                                        <h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Register</h5>

                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form2Example17">Email address</label>
                                            <input type="email" id="form2Example17"
                                                class="form-control form-control-lg" name="email" require/>
                                            
                                        </div>
                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form2Example17">Full Name</label>
                                            <input type="text" id="form2Example17"
                                                class="form-control form-control-lg" name="full_name" require/>
                                           
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form2Example27">Password</label>
                                            <input type="password" id="form2Example27"
                                                class="form-control form-control-lg" name="password" require/>
                                            
                                        </div>

                                        <div class="pt-1 mb-4">
                                            <!-- <button class="btn btn-dark btn-lg btn-block btn-set" type="button">Login</button> -->
                                            <button type='submit' name='submit' class="btn btn-dark btn-lg btn-block btn-set">Register</button>
                                        </div>

                                        <!-- <a class="small text-muted" href="#!">Forgot password?</a> -->
                                        <p class="mb-5 pb-lg-2" style="color: #393f81;">back to login? <a
                                                href="./index.php" style="color: #393f81;">Login here</a></p>

                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>











    <!-- 
    <div class="container">
        <div class="row">
            <div class="col">
                <img src="./img/login-logo.jpg" class="img-fluid mt-5" alt="...">
            </div>
            <div class="col">

            </div>
        </div>
    </div> -->



    <?php

if(isset($_POST['submit'])){
    $name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES (NULL, '$name', '$email', '$password', current_timestamp());";
    $result = $conn->query($query);
    if($conn->error){
        if (str_contains($conn->error, 'Duplicate')) {
            echo "<script>alert('Email Already Exist');</script>";
        }
        else
            echo "<script>alert('Unable to Register');</script>";
            
    }else{
        echo "<script>alert('Registeration Successfull');window.location.href = 'index.php';</script>"; 
    }
}
?>








    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>
    <script src="./script.js"></script>
</body>

</html>